import java.util.EnumMap;
import java.util.Stack;

public class Cubo {
    private EnumMap<Forma, Stack<Forma>> colonne;
    private final int capacita;

    public Cubo(int capacita) {
        this.capacita = capacita;
        colonne = new EnumMap<>(Forma.class);
        for (Forma f : Forma.values()) {
            colonne.put(f, new Stack<>());
        }
    }

    // Inserimento solo nella colonna corretta
    public boolean inserisci(Forma forma) {
        Stack<Forma> colonna = colonne.get(forma);
        if (colonna.size() < capacita) {
            colonna.push(forma);
            return true;
        } else {
            System.out.println("La colonna " + forma + " è piena!");
            return false;
        }
    }

    // Verifica se tutte le colonne hanno raggiunto la capacità massima
    public boolean pieno() {
        for (Stack<Forma> s : colonne.values()) {
            if (s.size() < capacita) return false;
        }
        return true;
    }

    // Mostra il cubo come tabella colonne
    public void mostra() {
        System.out.println("\nSTATO DEL CUBO:");
        int maxSize = 0;
        for (Stack<Forma> s : colonne.values()) {
            maxSize = Math.max(maxSize, s.size());
        }

        // intestazione
        System.out.printf("%-15s | %-15s | %-15s | %-15s%n",
                "QUADRATO", "TRIANGOLO", "CERCHIO", "PARALLELOGRAMMA");
        System.out.println("---------------------------------------------------------------");

        // stampa riga per riga dall’alto verso il basso
        for (int i = maxSize - 1; i >= 0; i--) {
            String quadrato = colonne.get(Forma.QUADRATO).size() > i ? "■" : "";
            String triangolo = colonne.get(Forma.TRIANGOLO).size() > i ? "▲" : "";
            String cerchio = colonne.get(Forma.CERCHIO).size() > i ? "●" : "";
            String parallelogramma = colonne.get(Forma.PARALLELOGRAMMA).size() > i ? "▰" : "";

            System.out.printf("%-15s | %-15s | %-15s | %-15s%n",
                    quadrato, triangolo, cerchio, parallelogramma);
        }
        System.out.println();
    }
}