public enum Forma {
    QUADRATO,
    TRIANGOLO,
    CERCHIO,
    PARALLELOGRAMMA;

    // Metodo per generare una forma casuale
    public static Forma random() {
        Forma[] values = Forma.values();
        int index = (int) (Math.random() * values.length);
        return values[index];
    }
}